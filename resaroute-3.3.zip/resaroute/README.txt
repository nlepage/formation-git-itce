Pr�sentation

L'agence de voyages Resanet a d�cid� de lancer le projet "resaroute", ce projet a pour but de cr�er uneapplication unique d'aspiration d'informations sur les sites de transports publics tels celui de la SNCF.
Les premi�res id�es du projet sont pr�sentes et vont �voluer au fur et � mesure. Le projet va aussidevoir d�buter sous peu. Un syst�me de versioning va devenir plus qu'important.
L'objectif principal est de mettre en place et g�rer les premiers �v�nements de ce d�p�t Git.

Le site est disponible � l'adresse http://www.resanet.com/resaroute/
